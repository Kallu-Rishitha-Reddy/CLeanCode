package com.rishitha;

public interface MaterialStandards {
    Integer standardMaterials();
    Integer aboveStandardMaterials();
    Integer highStandardMaterials();
}
