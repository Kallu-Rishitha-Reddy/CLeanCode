public interface SimpleIntrest {
    Double simpleInterest();
}
